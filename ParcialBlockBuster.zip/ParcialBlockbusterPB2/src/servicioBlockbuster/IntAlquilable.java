package servicioBlockbuster;

import dominioEnum.Clasificacion;

public interface IntAlquilable {

	 public  Double precioDeAlquiler ();
	 public  Boolean estaDisponible ();
	 public  void seAlquilo();
	 public  void seDevolvio();
	 public Clasificacion getClasificacion();
	 
	 
}
