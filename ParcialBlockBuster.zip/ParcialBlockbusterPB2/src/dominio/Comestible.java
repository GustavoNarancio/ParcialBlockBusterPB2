package dominio;

import servicioBlockbuster.IntVendible;

public class Comestible extends Producto implements IntVendible{

	
	private Double precioDeVenta;
	
	public Comestible(Integer codigo, String descripcion, Double precioDeVenta) {
		super(codigo, descripcion);
		this.precioDeVenta = precioDeVenta;
	}

	public Comestible(Integer codigo, String descripcion) {
		super(codigo, descripcion);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double precioDeVenta() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}
