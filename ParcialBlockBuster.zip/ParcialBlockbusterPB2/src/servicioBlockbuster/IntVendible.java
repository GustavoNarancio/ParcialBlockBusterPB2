   package servicioBlockbuster;

  public interface IntVendible {

	 Double precioDeVenta ();
}
