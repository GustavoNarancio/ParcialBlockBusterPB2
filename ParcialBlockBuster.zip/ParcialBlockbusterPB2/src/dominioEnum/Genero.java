package dominioEnum;

public enum Genero {
	 
	INFANTIL, COMEDIA, ACCION, TERROR, SUSPENSO;
	

}
