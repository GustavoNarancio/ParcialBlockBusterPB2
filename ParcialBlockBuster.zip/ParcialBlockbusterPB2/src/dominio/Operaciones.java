package dominio;

import dominioEnum.TipoDeOperacion;

public class Operaciones {

	
	private Cliente cliente;
	private Integer codigo;
	private TipoDeOperacion tipoDeOperacion;
	private Integer cantidad;
	private Producto producto;
	public Operaciones(Cliente cliente, Integer codigo, TipoDeOperacion tipoDeOperacion, Integer cantidad,
			Producto producto) {
		super();
		this.cliente = cliente;
		this.codigo = codigo;
		this.tipoDeOperacion = tipoDeOperacion;
		this.cantidad = cantidad;
		this.producto = producto;
	}
	
	
	
	
	
}
