package dominio;

import java.util.List;

import dominioEnum.Clasificacion;
import dominioEnum.Genero;
import servicioBlockbuster.IntAlquilable;
import servicioBlockbuster.IntVendible;

public class Pelicula extends Producto implements IntAlquilable, IntVendible {
	private Double precioDeVenta = 100.50;
	private Double precioDeAlquiler = 100.50;
    private String fechaDeEstreno;
    private String director;
    private List <String> actoresPrincipales;
    private Genero genero;
    private Boolean estaAqluilado = false;
    private Clasificacion clasificacion;
    

	public Pelicula(Integer codigo, String descripcion, Double precioDeVenta, Double precioDeAlquiler,
			String fechaDeEstreno, String director, List<String> actoresPrincipales, Genero genero, Clasificacion clasificacion) {
		super(codigo, descripcion);
		this.precioDeVenta = precioDeVenta;
		this.precioDeAlquiler = precioDeAlquiler;
		this.fechaDeEstreno = fechaDeEstreno;
		this.director = director;
		this.actoresPrincipales = actoresPrincipales;
		this.genero = genero;
		this.clasificacion = clasificacion;
	}

	public Pelicula(Integer codigo, String descripcion) {
		super(codigo, descripcion);
		
	}

	@Override
	public Double precioDeVenta() {

		return this.precioDeVenta;
	}

	@Override
	public Double precioDeAlquiler() {

		return precioDeAlquiler;
	}

	@Override
	public Boolean estaDisponible() {
		// TODO Auto-generated method stub
		return this.estaAqluilado;
	}

	@Override
	public void seAlquilo() {
	   this.estaAqluilado = true;
		
	}

	@Override
	public void seDevolvio() {
		
		 this.estaAqluilado = false;
	}

	public Double getPrecioDeVenta() {
		return precioDeVenta;
	}

	public Double getPrecioDeAlquiler() {
		return precioDeAlquiler;
	}

	public Boolean getEstaAqluilado() {
		return estaAqluilado;
	}

	@Override
	public Clasificacion getClasificacion() {
		 
		return clasificacion;
		
	}

	
	
	
	
}