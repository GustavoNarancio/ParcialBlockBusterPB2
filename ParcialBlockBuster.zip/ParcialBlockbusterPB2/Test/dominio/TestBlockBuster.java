package dominio;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import dominioEnum.Clasificacion;
import dominioEnum.Genero;
import dominioEnum.TipoDeConsola;
import dominioEnum.TipoDeOperacion;

public class TestBlockBuster {

	BlockBuster blockbuster;

	@Before
	public void init() {
		blockbuster = new BlockBuster();
	}

	@Test
	public void dadoQueExisteUnBlockBusterCuandoUnClienteQuiereComprarUnaPeliculaEntoncesBlockBusterSeLeVende1Pelicula() {
		Cliente cliente1 = new Cliente(01, "Capitan", "Huesos", 20);
		List<String> actoresTiburon = Arrays.asList("Leonardo DiCaprio", "Kate Winslet");
		Pelicula pelicula1 = new Pelicula(01, "Tiburon", 100.30, 10.10, "10-10-1999", "Spilber", actoresTiburon,
				Genero.SUSPENSO, Clasificacion.MAYORES_18);
		blockbuster.productos.add(pelicula1);
		Operaciones operacion = new Operaciones(cliente1, 01, TipoDeOperacion.COMPRA, 1, pelicula1);

		blockbuster.operaciones.add(operacion);
		blockbuster.clientes.add(cliente1);
		

		Boolean venta = blockbuster.venta(cliente1, pelicula1);

		assertTrue (venta);

	}

	@Test
	public void dadoQueExisteUnBlockBusterCuandoUnClienteQuiereAlquilarUnaPeliculaEntoncesBlockBusterSeLaAlquila() {
		Cliente cliente1 = new Cliente(01, "Capitan", "Huesos", 20);
		List<String> actoresTiburon = Arrays.asList("Leonardo DiCaprio", "Kate Winslet");
		Pelicula pelicula1 = new Pelicula(01, "Tiburon", 100.30, 10.10, "10-10-1999", "Spilber", actoresTiburon,
				Genero.SUSPENSO, Clasificacion.MAYORES_18);

		Operaciones operacion = new Operaciones(cliente1, 01, TipoDeOperacion.COMPRA, 1, pelicula1);
		blockbuster.operaciones.add(operacion);
		blockbuster.clientes.add(cliente1);
		blockbuster.productos.add(pelicula1);
		Boolean alquilaUnaPelicula = blockbuster.alquiler(cliente1, pelicula1);

		assertTrue(alquilaUnaPelicula);

	}

	@Test
	public void dadoQueExisteUnBlockBusterCuandoUnClienteQuiereAlquilarTresPeliculasEntoncesNoSePuedePorQueElLimiteEsDos() {

		Cliente cliente1 = new Cliente(01, "Capitan", "Huesos", 20);
		blockbuster.clientes.add(cliente1);
		List<String> actoresTiburon = Arrays.asList("Leonardo DiCaprio", "Kate Winslet");
		Pelicula pelicula1 = new Pelicula(01, "Tiburon", 100.30, 10.10, "10-10-1999", "Spilber", actoresTiburon,
				Genero.SUSPENSO, Clasificacion.MAYORES_18);
		blockbuster.productos.add(pelicula1);

		Pelicula pelicula2 = new Pelicula(02, "Tiburones", 100.30, 10.10, "10-10-1999", "Spilber", actoresTiburon,
				Genero.SUSPENSO, Clasificacion.MAYORES_18);
		blockbuster.productos.add(pelicula2);

		Pelicula pelicula3 = new Pelicula(04, "Puchi", 100.30, 10.10, "10-10-1999", "Spilber", actoresTiburon,
				Genero.SUSPENSO, Clasificacion.MAYORES_18);
		blockbuster.productos.add(pelicula3);

		Operaciones operacion = new Operaciones(cliente1, 01, TipoDeOperacion.COMPRA, 1, pelicula1);
		blockbuster.operaciones.add(operacion);

		Boolean alquilaUnaPelicula = blockbuster.alquiler(cliente1, pelicula1);
		Boolean alquilaDosPeliculas = blockbuster.alquiler(cliente1, pelicula2);
		Boolean alquilaTresPeliculas = blockbuster.alquiler(cliente1, pelicula3);

		assertTrue(alquilaUnaPelicula);
		assertTrue(alquilaDosPeliculas);
		assertFalse(alquilaTresPeliculas);

	}

	@Test
	public void dadoQueExisteUnBlockBusterCuandoUnClienteQuiereAlquilarUnVideoJuegoEntoncesBlockBusterLeAlquilaUnVideoJuego() {

		Cliente cliente1 = new Cliente(01, "Capitan", "Huesos", 20);
		blockbuster.clientes.add(cliente1);
		VideoJuego videoJuego = new VideoJuego(01, "Darksiders ", TipoDeConsola.PLAY_STATION, 10.20,
				Clasificacion.MAYORES_18);
		blockbuster.productos.add(videoJuego);
		Boolean alquiler  = blockbuster.alquiler(cliente1, videoJuego);
		assertTrue ( alquiler);
		
	}

	
	@Test 
	public void dadoQueExisteUnBlockBusterCuandoUnClienteQuiereComprarUnComestibleEntoncesBlockBusterSeLoVende () {
		
		Cliente cliente1 = new Cliente(01, "Capitan", "Huesos", 20);
		blockbuster.clientes.add(cliente1);
		Comestible comestible  = new Comestible (01, "caramelo", 30.02) ;
		blockbuster.productos.add(comestible);
		
		
		Boolean venta  = blockbuster.venta(cliente1, comestible);
		assertTrue ( venta);
		
		
		
		
	}
	
	@Test
	public void dadoQueExisteUnBlockBusterCuandoUnClienteQuiereAlquilarTresVideoJuegosEntoncesNoSePuedePorQueElLimiteEsDos() {

		Cliente cliente1 = new Cliente(01, "Capitan", "Huesos", 20);
		blockbuster.clientes.add(cliente1);
		VideoJuego videoJuego1 = new VideoJuego(01, "Darksiders ", TipoDeConsola.PLAY_STATION, 10.20,
				Clasificacion.MAYORES_18);
		blockbuster.productos.add(videoJuego1);
		VideoJuego videoJuego2 = new VideoJuego(01, "Darksiders ", TipoDeConsola.PLAY_STATION, 10.20,
				Clasificacion.MAYORES_18);
		blockbuster.productos.add(videoJuego2);
		VideoJuego videoJuego3 = new VideoJuego(01, "Darksiders ", TipoDeConsola.PLAY_STATION, 10.20,
				Clasificacion.MAYORES_18);
		blockbuster.productos.add(videoJuego3);

		Operaciones operacion1 = new Operaciones(cliente1, 01, TipoDeOperacion.COMPRA, 1, videoJuego1);
		blockbuster.operaciones.add(operacion1);
		Operaciones operacion2 = new Operaciones(cliente1, 01, TipoDeOperacion.COMPRA, 1, videoJuego2);
		blockbuster.operaciones.add(operacion2);
		Operaciones operacion3 = new Operaciones(cliente1, 01, TipoDeOperacion.COMPRA, 1, videoJuego3);
		blockbuster.operaciones.add(operacion3);

		Boolean alquilaUnaPelicula = blockbuster.alquiler(cliente1, videoJuego1);
		Boolean alquilaDosPeliculas = blockbuster.alquiler(cliente1, videoJuego2);
		Boolean alquilaTresPeliculas = blockbuster.alquiler(cliente1, videoJuego3);

		assertTrue(alquilaUnaPelicula);
		assertTrue(alquilaDosPeliculas);
		assertFalse(alquilaTresPeliculas);

	}

	
	
}
