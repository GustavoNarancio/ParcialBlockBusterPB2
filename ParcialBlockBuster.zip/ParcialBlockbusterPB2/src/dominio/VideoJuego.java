package dominio;

import dominioEnum.Clasificacion;
import dominioEnum.TipoDeConsola;
import servicioBlockbuster.IntAlquilable;

    public class VideoJuego extends Producto implements IntAlquilable {
 
	
	private TipoDeConsola tipoDeConsola;
	private Double precioDeAlquiler;
	private Boolean estaAqluilado = false;
	private Clasificacion clasificacion;
	
	
	public VideoJuego(Integer codigo, String descripcion, TipoDeConsola tipoDeConsola, Double precioDeAlquiler,
			 Clasificacion clasificacion) {
		super(codigo, descripcion);
		this.tipoDeConsola = tipoDeConsola;
		this.precioDeAlquiler = precioDeAlquiler;
		this.clasificacion = clasificacion;
	}


	public VideoJuego(Integer codigo, String descripcion, TipoDeConsola tipoDeConsola, Double precioDeAlquiler) {
		super(codigo, descripcion);
		this.tipoDeConsola = tipoDeConsola;
		this.precioDeAlquiler = precioDeAlquiler;
	}



	public VideoJuego(Integer codigo, String descripcion, TipoDeConsola tipoDeConsola) {
		super(codigo, descripcion);
		this.tipoDeConsola = tipoDeConsola;
	}



	public VideoJuego(Integer codigo, String descripcion) {
		super(codigo, descripcion);
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public Double precioDeAlquiler() {
		// TODO Auto-generated method stub
		return this.precioDeAlquiler;
	}



	@Override
	public Boolean estaDisponible() {
		// TODO Auto-generated method stub
		return this.estaAqluilado;
	}



	@Override
	public void seAlquilo() {
		this.estaAqluilado = true;
	}



	@Override
	public void seDevolvio() {
		this.estaAqluilado = false;
		
	}


	@Override
	public Clasificacion getClasificacion() {
		// TODO Auto-generated method stub
		return clasificacion;
	}
	
	 
	
	
}
