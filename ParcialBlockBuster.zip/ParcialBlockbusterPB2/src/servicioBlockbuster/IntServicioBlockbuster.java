package servicioBlockbuster;

import dominio.Cliente;
import dominio.Pelicula;
import dominio.Producto;

public interface IntServicioBlockbuster {
	public Boolean alquiler (Cliente cliente, Producto producto);
	public Boolean venta(Cliente cliente, Producto producto);
	
}
