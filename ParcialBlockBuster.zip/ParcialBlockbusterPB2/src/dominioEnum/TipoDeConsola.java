package dominioEnum;

public enum TipoDeConsola {

	PLAY_STATION, PC, WII;
	
}
