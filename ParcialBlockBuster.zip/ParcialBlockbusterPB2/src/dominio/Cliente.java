package dominio;

import java.util.ArrayList;
import java.util.List;

public class Cliente {

	private Integer codigo;
	private String nombre;
	private String apellido;
	private Integer edad;
	private List <Producto> productos;
	
	public Cliente(Integer codigo, String nombre, String apellido, Integer edad) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.productos = new ArrayList <> ();
		
	}

	public Integer getEdad() {
		return edad;
	}

	public List<Producto> getProductos() {
		return productos;
	}
	
	
	
}
