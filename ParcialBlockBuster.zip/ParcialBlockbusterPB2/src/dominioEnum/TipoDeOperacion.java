package dominioEnum;

public enum TipoDeOperacion {
 COMPRA, VENTA, ALQUILER;
}
