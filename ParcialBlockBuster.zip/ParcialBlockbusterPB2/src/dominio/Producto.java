package dominio;

public class Producto {

	private Integer codigo;
	private String descripcion;
	
	public Producto(Integer codigo, String descripcion) {
		super();
		this.codigo = codigo;
		this.descripcion = descripcion;
	}

	
	
}
