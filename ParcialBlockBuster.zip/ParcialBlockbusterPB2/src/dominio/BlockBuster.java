package dominio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import dominioEnum.Clasificacion;
import servicioBlockbuster.IntAlquilable;
import servicioBlockbuster.IntServicioBlockbuster;

public class BlockBuster implements IntServicioBlockbuster {
	List<Cliente> clientes;
	private Double caja = 00.00;
	private Integer cantidadDeAlquileresSimultaneos = 0;
	List<Operaciones> operaciones;
	List<Producto> productos;

	public BlockBuster() {
		clientes = new ArrayList<Cliente>();
		operaciones = new ArrayList<Operaciones>();
		productos = new ArrayList<>();

	}

	
	
	public List<Cliente> ordenardos ( ) {
		 clientes.sort( new Comparator< Cliente> ( ) {
				public int compare(Cliente o1, Cliente o2) {
					return o1.getEdad().compareTo(o2.getEdad());
				}
			 });
			  
		return this.clientes;
	}
	
	
	
	
	
	@Override
	public Boolean venta(Cliente cliente, Producto producto) {

		Boolean ventaExitosa = false;
		Boolean tengoElProducto = false;

		for (Producto generico : productos) {
			if ( productos.contains(producto) ) {
               tengoElProducto = true;
			}

			
			
			if (tengoElProducto && generico instanceof Pelicula) {

				if (((Pelicula) generico).getClasificacion().equals(Clasificacion.MAYORES_7)
						&& cliente.getEdad() >= 7) {
					ventaExitosa = true;

				}
				if (((Pelicula) generico).getClasificacion().equals(Clasificacion.MAYORES_18)
						&& cliente.getEdad() >= 18) {
					ventaExitosa = true;
				}

			} 

		 if (!(generico instanceof Pelicula)) {
			 ventaExitosa = true;
		 }
			
		}
		
		if (ventaExitosa) {

			cliente.getProductos().add(producto);
			this.productos.remove(producto);

		}
		
		return ventaExitosa;
	}

	
	
	@Override
	public Boolean alquiler(Cliente cliente, Producto producto) {
		Boolean alquilerExitoso = false;
		Boolean tengoLaPelicula = productos.contains(producto);

		if (tengoLaPelicula && this.cantidadDeAlquileresSimultaneos < 2) {
			if ( producto instanceof IntAlquilable)
			if ( ((IntAlquilable) producto).getClasificacion().equals(Clasificacion.MAYORES_7) && cliente.getEdad() >= 7) {
				alquilerExitoso = true;
				this.cantidadDeAlquileresSimultaneos++;
			}
			if (((IntAlquilable) producto).getClasificacion().equals(Clasificacion.MAYORES_18) && cliente.getEdad() >= 18) {
				alquilerExitoso = true;
				this.cantidadDeAlquileresSimultaneos++;
			}
		}
		if (alquilerExitoso) {
			cliente.getProductos().add(producto);
		}
		return alquilerExitoso;
	}

}
