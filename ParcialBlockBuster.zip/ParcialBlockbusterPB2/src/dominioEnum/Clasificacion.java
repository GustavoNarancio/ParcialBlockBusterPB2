package dominioEnum;

public enum Clasificacion {

	
	ATP, MAYORES_7, MAYORES_18;
}
